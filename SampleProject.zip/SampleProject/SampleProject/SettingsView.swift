//
//  SettingsView.swift
//  SampleProject
//
//  Created by Akshay Ahuja on 14/11/25.
//

import SwiftUI

struct SettingsView: View {
    //Dummy Data
    @State var menuItems: [SettingsItem] = [
        .close(ButtonItem(title: "xmark")),
        .button([ButtonItem(title: "Sign Up", isSelect: true), ButtonItem(title: "Log In", isSelect: false)]),
        .menu([MenuItem(icon: "person", title: "Name of the Profile"),
               MenuItem(icon: "list.bullet.rectangle", title: "Watchlist / Favourites"),
               MenuItem(icon: "arrow.down.to.line", title: "Downloads"),
               MenuItem(icon: "dollarsign.circle", title: "Buy Subscription / Plan"),
               MenuItem(icon: "envelope", title: "Contact Us"),
               MenuItem(icon: "checkmark.shield", title: "Privacy Policy"),
               MenuItem(icon: "rectangle.portrait.and.arrow.right", title: "Logout")],
             )
    ]

    var body: some View {
        ZStack(alignment: .top) {
            
            Color.black.ignoresSafeArea()
            VStack() {

                List(menuItems) { item in
                        switch item {
                        case .close(let btn):
                            HStack() {
                                Spacer()
                                Image(systemName: btn.title)
                                    .resizable()
                                    .foregroundColor(.white)
                                    .frame(width: 20, height: 20)
                            }
                            .listRowBackground(Color.clear)
                            .frame(height: 0)
                        case .button(let items):
                            HStack(spacing: 16) {
                                ForEach(items) { item in
                                    Button(action: {}) {
                                        Text(item.title)
                                            .frame(maxWidth: .infinity, minHeight: 44)
                                            .fontWeight(.medium)
                                            .foregroundColor(item.isSelect ? .black : .yellow)
                                            .background(item.isSelect ? Color.yellow : .clear)
                                            .cornerRadius(8)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 8)
                                                    .stroke(!item.isSelect ? Color.yellow : .clear, lineWidth: 1)
                                                    .background(.clear)
                                            )
                                    }
                                }
                            }
                            .listRowBackground(Color.clear)
                            .frame(minHeight: 80)
                        case .menu(let mItems):
                            ForEach(mItems) { items in
                                HStack {
                                    Image(systemName: items.icon)
                                        .foregroundColor(items.title != "Logout" ? .white : .red)
                                        .frame(width: 26, height: 26)
                                    Text(items.title)
                                        .foregroundColor(items.title != "Logout" ? .white : .red)
                                    Spacer()
                                }
                                .listRowBackground(Color.gray.opacity(0.16))
                                .listRowSeparatorTint(Color(red: 33/255, green: 34/255, blue: 44/255))
                            }
                        }
                }
                .scrollContentBackground(.hidden)
                .background(Color.black)
            }
        }
    }
}

#Preview {
    SettingsView()
}
