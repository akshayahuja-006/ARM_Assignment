//
//  SampleProjectApp.swift
//  SampleProject
//
//  Created by Akshay Ahuja on 12/11/25.
//

import SwiftUI

@main
struct SampleProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
