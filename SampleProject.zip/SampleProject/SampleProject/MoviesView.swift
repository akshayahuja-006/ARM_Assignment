//
//  MoviesView.swift
//  SampleProject
//
//  Created by Akshay Ahuja on 13/11/25.
//

import SwiftUI

struct MoviesView: View {
    @State private var searchText = ""
    
    let demoBanner = Banner(
        title: "IRRFAN",
        subtitle: "THE CRIME SPECIAL ORIGINALS",
        imageName: "Banner", height: 500
    )

    let demoDocumentaries: [Documentary] = [
        Documentary(title: "ICELAND", imageName: "Card-3"),
        Documentary(title: "UKRAIN", imageName: "Card-2"),
        Documentary(title: "ICELAND", imageName: "Card-3"),
        Documentary(title: "OTHER", imageName: "Card-1"),
    ]

    let demoReleases: [Documentary] = [
        Documentary(title: "FARHAN AKHTAR", imageName: "Card-1"),
        Documentary(title: "HANS ZIMMER", imageName: "Card-4"),
        Documentary(title: "MARK QUINN", imageName: "Card-5"),
        Documentary(title: "AR RAHMAN", imageName: "Card-1"),
    ]
    
    var body: some View {
        NavigationView {
            ZStack {
                List {
                    // Search Bar
                    Section {
                        SearchBar(text: $searchText, placeholder: "Search your documentaries here")
                        .padding(8)
                        .background(Color(.clear))
                        .cornerRadius(8)
                    }
                    .listRowInsets(EdgeInsets())
                    .listRowBackground(Color.gray.opacity(0.16))
                    
                    // Banner Main Feature
                    Section {
                        BannerView(banner: demoBanner)
                            .listRowInsets(EdgeInsets())
                            .padding(.vertical)
                            .background(Color(.clear))
                    }
                    .listRowBackground(Color.clear)
                    
                    // Documentaries - Horizontal List
                    Section(header: Text("Documentaries").font(.title2).bold().foregroundStyle(.white).padding([.top, .bottom], 8)) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(demoDocumentaries) { doc in
                                    DocumentaryCardView(doc: doc)
                                }
                            }
                            .padding(.horizontal)
                        }
                        .listRowInsets(EdgeInsets())
                    }
                    .listRowBackground(Color.gray.opacity(0.16))
                    
                    // New Releases - Horizontal List
                    Section(header: Text("New Releases").font(.title2).bold().foregroundStyle(.white).padding([.top, .bottom], 8)) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(demoReleases) { doc in
                                    DocumentaryCardView(doc: doc)
                                }
                            }
                            .padding(.horizontal)
                        }
                        .listRowInsets(EdgeInsets())
                    }
                    .listRowBackground(Color.gray.opacity(0.16))
                }
                .scrollContentBackground(.hidden)
                .background(Color.black)
                .listStyle(PlainListStyle())
                .navigationBarHidden(true)
            }
        }
    }
}

#Preview {
    MoviesView()
}

struct BannerView: View {
    let banner: Banner

    var body: some View {
        ZStack(alignment: .bottom) {
            Image(banner.imageName)
                .resizable()
                .scaledToFill()
                .frame(height: banner.height)
                .clipped()
        }
        .cornerRadius(10)
        .padding(.horizontal)
    }
}

struct DocumentaryCardView: View {
    let doc: Documentary

    var body: some View {
        VStack {
            Image(doc.imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 120, height: 170)
                .cornerRadius(8)
            Text(doc.title)
                .font(.caption)
                .foregroundColor(.primary)
        }
        .frame(width: 120)
    }
}

