//
//  HomeView.swift
//  SampleProject
//
//  Created by Akshay Ahuja on 12/11/25.
//

import SwiftUI

struct HomeView: View {

    let dummyData: [HomeTextElementModel] = [HomeTextElementModel(title: "The Creative Network", subTitle: "The Creative Network is the best streaming experience for watching your favorite movies and shows on demand, anytime, anywhere.", btnTitle: "Explore Now")]
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            List {
                ZStack(alignment: .top) {
                    Image("Home")
                        .resizable()
                    Image("Logo")
                        .padding(.top, 25)
                }
                .listRowBackground(Color.clear)
                
                ForEach(dummyData) { item in
                    VStack(alignment: .center, spacing: 20) {
                        Text(item.title)
                            .font(Font.title.bold())
                            .foregroundStyle(Color.white)
                        Text(item.subTitle)
                            .font(.footnote)
                            .foregroundStyle(Color.gray)
                            .multilineTextAlignment(.center)
                        Button(action: {}) {
                            Text(item.btnTitle)
                                .frame(maxWidth: 150, minHeight: 44)
                                .fontWeight(.medium)
                                .foregroundColor(.black)
                                .background(Color.yellow)
                                .cornerRadius(8)
                        }
                        
                    }
                    .listRowBackground(Color.clear)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
        }
    }
}

#Preview {
    HomeView()
}
