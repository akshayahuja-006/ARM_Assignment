//
//  ContentView.swift
//  SampleProject
//
//  Created by Akshay Ahuja on 12/11/25.
//

import SwiftUI

struct ContentView: View {
    
    @State private var selectedTab = 0
    
    var body: some View {
        VStack(spacing: 0) {
            
            Group {
                if selectedTab == 0 {
                    HomeView()
                } else if selectedTab == 1 {
                    MoviesView()
                } else if selectedTab == 2 {
                    ArtistDirectoryView()
                } else if selectedTab == 3 {
                    SettingsView()
                }
            }
            CustomTabBar(selected: $selectedTab)
        }
        .edgesIgnoringSafeArea(.top)
        .background(Color(.systemBackground))
    }
}

#Preview {
    ContentView()
}
