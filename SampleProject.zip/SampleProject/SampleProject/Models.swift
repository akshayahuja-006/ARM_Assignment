//
//  Untitled.swift
//  SampleProject
//
//  Created by Akshay Ahuja on 15/11/25.
//
import Foundation

struct CustomBarTab: Identifiable {
    let id: Int
    let icon: String
    let label: String
}

enum SettingsItem: Identifiable {
    var id: UUID {
        UUID()
    }
    
    case close(ButtonItem)
    case button([ButtonItem])
    case menu([MenuItem])
}

struct ButtonItem: Identifiable {
    let id = UUID()
    let title: String
    var isSelect = false
}

struct MenuItem: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
}

struct Documentary: Identifiable {
    let id = UUID()
    let title: String
    let imageName: String
}

struct Banner {
    let title: String
    let subtitle: String
    let imageName: String
    let height: CGFloat
}

struct HomeTextElementModel: Identifiable {
    let id = UUID()
    let title: String
    let subTitle: String
    let btnTitle: String
}

struct DirectoryFilter: Identifiable {
    let id = UUID()
    let title: String
    let options: [String]
    var selectedOption: String?
}
