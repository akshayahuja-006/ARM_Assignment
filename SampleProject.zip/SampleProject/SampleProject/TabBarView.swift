//
//  TabBarView.swift
//  SampleProject
//
//  Created by Akshay Ahuja on 14/11/25.
//

import SwiftUI

struct CustomTabBar: View {
    
    @Binding var selected: Int
    let tabs: [CustomBarTab] = [
        CustomBarTab(id: 0, icon: "house.fill", label: ""),
        CustomBarTab(id: 1, icon: "video", label: "Movies"),
        CustomBarTab(id: 2, icon: "person.3", label: "Artist"),
        CustomBarTab(id: 3, icon: "line.3.horizontal", label: "")
    ]

    var body: some View {
        GeometryReader { geo in
            HStack(spacing: 0) {
                ForEach(tabs) { tab in
                    Button {
                        withAnimation(.spring(response: 0.4, dampingFraction: 1)) {
                            selected = tab.id
                        }
                    } label: {
                        HStack(spacing: selected == tab.id ? 0 : 0) {
                            Image(systemName: tab.icon)
                                .foregroundColor(selected == tab.id ? .yellow : .white)
                                .font(.system(size: 20))
                                .frame(minWidth: 0, maxWidth: .infinity)
                            if selected == tab.id {
                                Text(tab.label)
                                    .foregroundColor(.white)
                                    .font(.system(size: 16, weight: .medium))
                                    .fixedSize(horizontal: true, vertical: false)
                                    .layoutPriority(1)
                                    .transition(.opacity)
                            }
                        }
                        .padding(.vertical, 0)
                    }
                }
            }
            .frame(width: geo.size.width, height: 82)
            .background(Color(red: 30/255, green: 30/255, blue: 30/255))
        }
        .frame(height: 62)
    }
}

#Preview {
    @Previewable @State var selection: Int = 1
    CustomTabBar(selected: $selection)
}
