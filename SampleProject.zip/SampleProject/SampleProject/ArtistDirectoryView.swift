//
//  ArtistDirectoryView.swift
//  SampleProject
//
//  Created by Akshay Ahuja on 15/11/25.
//

import SwiftUI

struct SearchBar: View {
    @Binding var text: String
    var placeholder: String

    var body: some View {
        HStack {
            ZStack(alignment: .leading) {
                if text.isEmpty {
                    Text(placeholder)
                        .foregroundColor(Color.gray.opacity(0.76))
                        .padding(.leading, 12)
                }
                TextField("", text: $text)
                    .frame(height: 50)
                    .foregroundColor(.white)
            }
            .background(Color.black.opacity(0.82))
            .cornerRadius(8)
            .frame(height: 40)
            Image(systemName: "magnifyingglass")
                .foregroundColor(.white)
                .padding(.leading, -36)
        }
        
    }
}


struct ArtistDirectoryView: View {
    @State private var searchText = ""
    @State private var filters: [DirectoryFilter] = [
        DirectoryFilter(title: "Country", options: ["India", "USA", "UK"], selectedOption: nil),
        DirectoryFilter(title: "State", options: ["Maharashtra", "California", "London"], selectedOption: nil),
        DirectoryFilter(title: "City", options: ["Mumbai", "Los Angeles", "London"], selectedOption: nil),
        DirectoryFilter(title: "Industry", options: ["Art", "Music", "Film"], selectedOption: nil),
        DirectoryFilter(title: "Category", options: ["Painter", "Singer", "Director"], selectedOption: nil),
        DirectoryFilter(title: "Organisation", options: ["Gallery1", "Studio2"], selectedOption: nil)
    ]
    
    var body: some View {
        ZStack {
            GeometryReader { geo in
                Image("ArtistBG")
                    .resizable()
                    .frame(width: geo.size.width, height: geo.size.height * 1)
                    .scaledToFill()
                    .ignoresSafeArea()
            }
            
            VStack(spacing: 28) {
                SearchBar(text: $searchText, placeholder: "Search your artist here")
                
                HStack {
                    Spacer()
                    VStack(spacing: 15) {
                        // Dropdowns
                        ForEach($filters) { $filter in
                            Menu {
                                ForEach(filter.options, id: \.self) { option in
                                    Button(option) { filter.selectedOption = option }
                                }
                            } label: {
                                HStack {
                                    Text(filter.selectedOption ?? "Select \(filter.title)")
                                        .foregroundColor(.white)
                                    Spacer()
                                    Image(systemName: "chevron.down")
                                        .foregroundColor(.white)
                                }
                                .padding(.horizontal, 14)
                                .frame(width: 250,height: 42)
                                .background(Color.black.opacity(0.45))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.white.opacity(0.27), lineWidth: 1)
                                )
                            }
                        }
                    }
                }
                .padding(.horizontal, 8)
               
                
                HStack {
                    Spacer()
                    // Search Button
                    Button(action: { /* Search action */ }) {
                        Text("Search")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: 250)
                            .padding(.vertical, 12)
                            .background(Color.white.opacity(0.85))
                            .cornerRadius(8)
                    }
                    .padding([.horizontal], 8)
                }
                Spacer()
            }
            .padding(.top, 66)
            .padding(.horizontal, 12)
        }
    }
}

#Preview {
    ArtistDirectoryView()
}
